const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

let messages = [];

io.on("connection", (socket) => {
  console.log("Пользователь подключился:", socket.id);
  socket.emit("init", messages);

  socket.on("send", (data) => {
    messages.push(data);
    if (messages.length > 50) messages.shift();
    io.emit("message", data);
  });

  socket.on("disconnect", () => {
    console.log("Отключился:", socket.id);
  });
});

const PORT = process.env.PORT || 10000;
server.listen(PORT, () => console.log("WebSocket сервер запущен на порту", PORT));
